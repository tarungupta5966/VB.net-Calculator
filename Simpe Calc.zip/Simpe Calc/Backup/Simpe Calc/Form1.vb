Public Class Form1
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    'Programmed by: Haseeb Jamal Khan, 4rth Semester, 2008
    'Deptt. of Civil Engg. University of Engg. & Technology, Peshawar.
    ' For further information and querries plz contact me at haseebjamal_stn@yahoo.com
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Dim Num1 As Double
    Dim Num2 As Double
    Dim R As Double
    Dim SR As String
    Dim Num1sin As Double
    Dim Num1cos As Double
    Dim Num1log As String
    Sub getval()
        Num1 = CDbl(txtNum1.Text)
        Num2 = CDbl(txtNum2.Text)
    End Sub
    Sub mult()
        R = Num1 * Num1
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub pi()
        R = Math.PI
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub exp()
        R = Math.Exp(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub pow()
        R = Math.Pow(Num1, Num2)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub sqr()
        R = Math.Sqrt(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub acos()
        R = Math.Acos(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub asin()
        R = Math.Asin(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub ln()
        R = Math.Log10(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub log()
        R = Math.Log(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub cos()
        R = Math.Cos(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub sin()
        R = Math.Sin(Num1)
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub minus()
        R = Num1 - Num2
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub div()
        R = Num1 / Num2
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.text = SR
    End Sub
    Sub pro()
        R = Num1 * Num2
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Sub sum()
        R = Num1 + Num2
        R = Math.Round(R, 4)
        SR = "Ans Is..."
        SR = SR & vbCrLf
        SR = SR & R.ToString
        lblres.Text = SR
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        getval()
        sum()
    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        getval()
        cos()
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        getval()
        sin()
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        getval()
        minus()
    End Sub
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        getval()
        div()
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        getval()
        pro()
    End Sub
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        getval()
        log()
    End Sub
    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        getval()
        ln()
    End Sub
    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        getval()
        asin()
    End Sub
    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        getval()
        acos()
    End Sub
    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        getval()
        sqr()
    End Sub
    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        getval()
        pow()
    End Sub
    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        getval()
        pi()
    End Sub
    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        getval()
        exp()
    End Sub
    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        getval()
        mult()
    End Sub
    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        MsgBox(" Programmed by: Haseeb Jamal Khan, 4rth Semester, 2008" & vbCrLf & "Deptt. of Civil Engg. University of Engg. & Technology, Peshawar." & vbCrLf & "For further information and querries plz contact me at haseebjamal_stn@yahoo.com")
    End Sub
End Class